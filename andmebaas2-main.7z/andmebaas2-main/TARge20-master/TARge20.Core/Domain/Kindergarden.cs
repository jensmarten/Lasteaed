﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Kindergarden
    {
        public Guid KindergardenID { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public int Phone { get; set; }


    }
}

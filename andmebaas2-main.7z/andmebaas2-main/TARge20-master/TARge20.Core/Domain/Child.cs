﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Child
    {
        public Guid ChildID { get; set; }
        public string Name { get; set; }
        public int ParentsPhone { get; set; }
        public DateTime DOB { get; set; }
        public ICollection<GroupHistory> GroupHistories { get; set; }
        public ICollection<AbsentNotice> AbsentNotices { get; set; }
        public Groups group { get; set; }
    }
}

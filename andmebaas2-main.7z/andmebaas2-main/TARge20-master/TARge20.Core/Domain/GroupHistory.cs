﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class GroupHistory
    {
        public Guid GroupHistoryID { get; set; }
        public string LastGroup { get; set; }
        public string CurrentGroup { get; set; }
        public string AllGroups { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Kitchen
    {
        public Guid KitchenID { get; set; }
        public string Menu { get; set; }
        public ICollection<Portions> Portions { get; set; }
    }
}

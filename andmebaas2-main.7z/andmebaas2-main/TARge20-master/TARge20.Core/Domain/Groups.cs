﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Groups
    {
        [Key]
        public Guid GroupID { get; set; }
        public string GroupType { get; set; }
        public int groupYear { get; set; }
        public ICollection<Employees> Employee { get; set; }
        public ICollection<Child> Children { get; set; }
        public ICollection<Queue> Queues { get; set; }

    }
}

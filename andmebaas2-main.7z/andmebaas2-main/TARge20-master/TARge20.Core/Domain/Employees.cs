﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Employees
    {
        [Key]
        public Guid EmployeeID { get; set; }
        public string name { get; set; }
        public DateTime DOB { get; set; }
        public string address { get; set; }
        public int phoneNr { get; set; }
        public int salary { get; set; }
        public string email { get; set; }
        public string WorkSchedule { get; set; }
        public Job Jobs { get; set; }
        public ICollection<WorkHistory> WorkHistories { get; set; }

        public Groups group { get; set; }
        public ICollection<Kitchen> Kitchens { get; set; }
    }
}

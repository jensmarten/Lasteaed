﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Queue 
    {
        public Guid QueueID { get; set; }
        public string ChildName { get; set; }
        public int phone { get; set; }
    }
}

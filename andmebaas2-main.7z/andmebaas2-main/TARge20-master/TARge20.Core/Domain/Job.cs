﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Job
    {
        [Key]
        public Guid JobID { get; set; }
        public string JobTitle { get; set; }
    }
}

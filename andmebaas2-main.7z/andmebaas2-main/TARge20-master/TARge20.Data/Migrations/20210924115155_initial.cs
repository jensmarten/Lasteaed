﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Group",
                columns: table => new
                {
                    GroupID = table.Column<Guid>(nullable: false),
                    GroupType = table.Column<string>(nullable: true),
                    groupYear = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Group", x => x.GroupID);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                columns: table => new
                {
                    JobID = table.Column<Guid>(nullable: false),
                    JobTitle = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.JobID);
                });

            migrationBuilder.CreateTable(
                name: "Kindergardens",
                columns: table => new
                {
                    KindergardenID = table.Column<Guid>(nullable: false),
                    name = table.Column<string>(nullable: true),
                    address = table.Column<string>(nullable: true),
                    Phone = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kindergardens", x => x.KindergardenID);
                });

            migrationBuilder.CreateTable(
                name: "Children",
                columns: table => new
                {
                    ChildID = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    ParentsPhone = table.Column<int>(nullable: false),
                    DOB = table.Column<DateTime>(nullable: false),
                    GroupID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Children", x => x.ChildID);
                    table.ForeignKey(
                        name: "FK_Children_Group_GroupID",
                        column: x => x.GroupID,
                        principalTable: "Group",
                        principalColumn: "GroupID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Queues",
                columns: table => new
                {
                    QueueID = table.Column<Guid>(nullable: false),
                    ChildName = table.Column<string>(nullable: true),
                    phone = table.Column<int>(nullable: false),
                    GroupsGroupID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Queues", x => x.QueueID);
                    table.ForeignKey(
                        name: "FK_Queues_Group_GroupsGroupID",
                        column: x => x.GroupsGroupID,
                        principalTable: "Group",
                        principalColumn: "GroupID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    EmployeeID = table.Column<Guid>(nullable: false),
                    name = table.Column<string>(nullable: true),
                    DOB = table.Column<DateTime>(nullable: false),
                    address = table.Column<string>(nullable: true),
                    phoneNr = table.Column<int>(nullable: false),
                    salary = table.Column<int>(nullable: false),
                    email = table.Column<string>(nullable: true),
                    WorkSchedule = table.Column<string>(nullable: true),
                    JobsJobID = table.Column<Guid>(nullable: true),
                    GroupID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.EmployeeID);
                    table.ForeignKey(
                        name: "FK_Employee_Group_GroupID",
                        column: x => x.GroupID,
                        principalTable: "Group",
                        principalColumn: "GroupID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Employee_Job_JobsJobID",
                        column: x => x.JobsJobID,
                        principalTable: "Job",
                        principalColumn: "JobID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "absentNotices",
                columns: table => new
                {
                    AbsentNoticeID = table.Column<Guid>(nullable: false),
                    TotalDays = table.Column<int>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    ChildID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_absentNotices", x => x.AbsentNoticeID);
                    table.ForeignKey(
                        name: "FK_absentNotices_Children_ChildID",
                        column: x => x.ChildID,
                        principalTable: "Children",
                        principalColumn: "ChildID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "GroupHistories",
                columns: table => new
                {
                    GroupHistoryID = table.Column<Guid>(nullable: false),
                    LastGroup = table.Column<string>(nullable: true),
                    CurrentGroup = table.Column<string>(nullable: true),
                    AllGroups = table.Column<string>(nullable: true),
                    ChildID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GroupHistories", x => x.GroupHistoryID);
                    table.ForeignKey(
                        name: "FK_GroupHistories_Children_ChildID",
                        column: x => x.ChildID,
                        principalTable: "Children",
                        principalColumn: "ChildID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Kitchens",
                columns: table => new
                {
                    KitchenID = table.Column<Guid>(nullable: false),
                    Menu = table.Column<string>(nullable: true),
                    EmployeesEmployeeID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kitchens", x => x.KitchenID);
                    table.ForeignKey(
                        name: "FK_Kitchens_Employee_EmployeesEmployeeID",
                        column: x => x.EmployeesEmployeeID,
                        principalTable: "Employee",
                        principalColumn: "EmployeeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "WorkHistories",
                columns: table => new
                {
                    WorkhistoryID = table.Column<Guid>(nullable: false),
                    LastJob = table.Column<string>(nullable: true),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    EmployeesEmployeeID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkHistories", x => x.WorkhistoryID);
                    table.ForeignKey(
                        name: "FK_WorkHistories_Employee_EmployeesEmployeeID",
                        column: x => x.EmployeesEmployeeID,
                        principalTable: "Employee",
                        principalColumn: "EmployeeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Portions",
                columns: table => new
                {
                    PortionID = table.Column<Guid>(nullable: false),
                    MealInfo = table.Column<string>(nullable: true),
                    NutritionalInfo = table.Column<string>(nullable: true),
                    DistriputedPortions = table.Column<int>(nullable: false),
                    KitchenID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Portions", x => x.PortionID);
                    table.ForeignKey(
                        name: "FK_Portions_Kitchens_KitchenID",
                        column: x => x.KitchenID,
                        principalTable: "Kitchens",
                        principalColumn: "KitchenID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_absentNotices_ChildID",
                table: "absentNotices",
                column: "ChildID");

            migrationBuilder.CreateIndex(
                name: "IX_Children_GroupID",
                table: "Children",
                column: "GroupID");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_GroupID",
                table: "Employee",
                column: "GroupID");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_JobsJobID",
                table: "Employee",
                column: "JobsJobID");

            migrationBuilder.CreateIndex(
                name: "IX_GroupHistories_ChildID",
                table: "GroupHistories",
                column: "ChildID");

            migrationBuilder.CreateIndex(
                name: "IX_Kitchens_EmployeesEmployeeID",
                table: "Kitchens",
                column: "EmployeesEmployeeID");

            migrationBuilder.CreateIndex(
                name: "IX_Portions_KitchenID",
                table: "Portions",
                column: "KitchenID");

            migrationBuilder.CreateIndex(
                name: "IX_Queues_GroupsGroupID",
                table: "Queues",
                column: "GroupsGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_WorkHistories_EmployeesEmployeeID",
                table: "WorkHistories",
                column: "EmployeesEmployeeID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "absentNotices");

            migrationBuilder.DropTable(
                name: "GroupHistories");

            migrationBuilder.DropTable(
                name: "Kindergardens");

            migrationBuilder.DropTable(
                name: "Portions");

            migrationBuilder.DropTable(
                name: "Queues");

            migrationBuilder.DropTable(
                name: "WorkHistories");

            migrationBuilder.DropTable(
                name: "Children");

            migrationBuilder.DropTable(
                name: "Kitchens");

            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.DropTable(
                name: "Group");

            migrationBuilder.DropTable(
                name: "Job");
        }
    }
}

﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }

        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<AbsentNotice> absentNotices { get; set; }
        public DbSet<Child> Children { get; set; }
        public DbSet<Employees> Employee { get; set; }
        public DbSet<GroupHistory> GroupHistories { get; set; }
        public DbSet<Groups> Group { get; set; }
        public DbSet<Job> Job { get; set; }
        public DbSet<Kindergarden> Kindergardens { get; set; }
        public DbSet<Kitchen> Kitchens { get; set; }
        public DbSet<Portions> Portions { get; set; }
        public DbSet<Queue> Queues { get; set; }
        public DbSet<WorkHistory> WorkHistories { get; set; }

    }
}